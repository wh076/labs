#ifndef TABLE_H_INCLUDED
#define TABLE_H_INCLUDED

#include <iostream>
#include <vector>
using namespace std;

class Table{
private:
    int rows;
    int cols;
    vector<vector<int>> data;
public:
    // �����������
    Table(int rows, int cols);

    int get_value(int row, int col) const;

    void set_value(int row, int col, int value);

    int n_rows();

    int n_cols();

    void print();
};

#endif // TABLE_H_INCLUDED

#include <iostream>
#include "OddEvenSeparator.h"

void OddEvenSeparator::add_number(int number){
    numbers.push_back(number);
    if (number%2==0)
        evenNumbers.push_back(number);
    else
        oddNumbers.push_back(number);
}

void OddEvenSeparator::print_even(){
    cout << "even: ";
    for (int n : evenNumbers){
        cout << n << " ";
    }
    cout << endl;
}

void OddEvenSeparator::print_odd(){
    cout << "odd: ";
    for (int n : oddNumbers){
        cout << n << " ";
    }
    cout << endl;
}

#include <iostream>
#include "OddEvenSeparator.h"

using namespace std;

int main()
{
    OddEvenSeparator separator;
    separator.add_number(1);
    separator.add_number(14);
    separator.add_number(3);
    separator.add_number(534);
    separator.add_number(67);
    separator.add_number(2);
    separator.add_number(8);
    separator.add_number(121);

    separator.print_even();
    separator.print_odd();

    return 0;
}

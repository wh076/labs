#ifndef ODDEVENSEPARATOR_H_INCLUDED
#define ODDEVENSEPARATOR_H_INCLUDED

#include <iostream>
#include <vector>

using namespace std;

class OddEvenSeparator{
private:
    vector<int> numbers;
    vector<int> evenNumbers;
    vector<int> oddNumbers;
public:
    void add_number(int number);
    void print_even();
    void print_odd();
};

#endif // ODDEVENSEPARATOR_H_INCLUDED

#ifndef BELL_H_INCLUDED
#define BELL_H_INCLUDED

#include <iostream>
#include <string>

using namespace std;

class Bell {
private:
    bool isDing;
public:
    Bell();
    void sound();
};

#endif // BELL_H_INCLUDED

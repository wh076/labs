#include <iostream>
#include "Bell.h"

using namespace std;

int main()
{
    Bell bell;

    bell.sound();
    bell.sound();
    bell.sound();
    bell.sound();
    return 0;
}

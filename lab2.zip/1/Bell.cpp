#include "Bell.h"
#include <iostream>

using namespace std;
Bell::Bell() : isDing(true){}

void Bell::sound(){
    if (isDing)
        cout << "ding" << endl;
    else
        cout << "dong" << endl;
    isDing = !isDing;
}
